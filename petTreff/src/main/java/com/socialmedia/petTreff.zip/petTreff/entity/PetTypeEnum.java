package com.socialmedia.petTreff.entity;

public enum PetTypeEnum {
    DOG,
    CAT,
    BIRD,
    REPTILE,
    RABBIT,
    OTHER
}
