package com.socialmedia.petTreff.entity;

public enum LookingFor
{ PLAYDATES, TRAINING, SITTING, MEETUPS }


