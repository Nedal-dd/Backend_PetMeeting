package com.socialmedia.petTreff.dto;

import lombok.Data;

@Data
public class RoleDTO {

    private String authority;
}
