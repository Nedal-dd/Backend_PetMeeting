package com.socialmedia.petTreff.entity;

public enum NotificationType {
    GENERAL, FRIEND_REQUEST, CHAT, MATCH
}
