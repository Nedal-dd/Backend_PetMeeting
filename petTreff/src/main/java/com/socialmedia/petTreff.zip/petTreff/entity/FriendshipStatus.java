package com.socialmedia.petTreff.entity;

public enum FriendshipStatus {

    PENDING, ACCEPTED, DECLINED,NONE;
}
