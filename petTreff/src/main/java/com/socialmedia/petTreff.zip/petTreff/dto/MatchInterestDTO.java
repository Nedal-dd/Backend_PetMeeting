package com.socialmedia.petTreff.dto;

import lombok.Data;

@Data
public class MatchInterestDTO {
    private Long matchRequestId;

}
