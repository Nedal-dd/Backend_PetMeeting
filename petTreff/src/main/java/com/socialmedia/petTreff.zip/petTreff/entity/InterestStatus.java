package com.socialmedia.petTreff.entity;

public enum InterestStatus {

    PENDING, ACCEPTED, DECLINED
}
