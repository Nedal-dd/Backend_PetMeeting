package com.socialmedia.petTreff.entity;

public enum MatchRequestStatus {
    OPEN, CLOSED, ACCEPTED
}
